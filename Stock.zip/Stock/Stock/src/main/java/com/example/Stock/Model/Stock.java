package com.example.Stock.Model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class Stock {
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name="id")
		private int id; 

		private String item;
		
		private long selling_price;
		private long purchase_price;
		private long quantity_left;
		private long total_quantity;
		public int getId() {
			return id;
		}
		public void setId(int id) {
			this.id = id;
		}
		public String getItem() {
			return item;
		}
		public void setItem(String item) {
			this.item = item;
		}
		public long getSelling_price() {
			return selling_price;
		}
		public void setSelling_price(long selling_price) {
			this.selling_price = selling_price;
		}
		public long getPurchase_price() {
			return purchase_price;
		}
		public void setPurchase_price(long purchase_price) {
			this.purchase_price = purchase_price;
		}
		public long getQuantity_left() {
			return quantity_left;
		}
		public void setQuantity_left(long quantity_left) {
			this.quantity_left = quantity_left;
		}
		public long getTotal_quantity() {
			return total_quantity;
		}
		public void setTotal_quantity(long total_quantity) {
			this.total_quantity = total_quantity;
		}
		public Stock() {
			super();
			// TODO Auto-generated constructor stub
		}
		public Stock(String item, long selling_price, long purchase_price, long quantity_left,
				long total_quantity) {
			super();
			this.id = id;
			this.item = item;
			this.selling_price = selling_price;
			this.purchase_price = purchase_price;
			this.quantity_left = quantity_left;
			this.total_quantity = total_quantity;
		}
		@Override
		public String toString() {
			return "Stock [id=" + id + ", item=" + item + ", selling_price=" + selling_price + ", purchase_price="
					+ purchase_price + ", quantity_left=" + quantity_left + ", total_quantity=" + total_quantity + "]";
		}
		
		
			

}
