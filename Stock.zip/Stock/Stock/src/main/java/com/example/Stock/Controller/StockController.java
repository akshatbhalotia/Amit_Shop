package com.example.Stock.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.example.Stock.Model.Stock;
import com.example.Stock.Repository.StockRepo;

@Controller
public class StockController {
	
	@Autowired 
	StockRepo stockrepo;
	
	@GetMapping("/listItem")
	public List<Stock> list()
	{
return stockrepo.findAll();
	}
	
	
	@RequestMapping(path="/refreshquantity",method=RequestMethod.GET)
	public String refresh()
	{
		List<Stock> d = stockrepo.findAll();
		long total=0;
		long left=0;
		long n=0;
		long l = d.size();
		for(int j=0;j<l;j++)
		{
		total = d.get(j).getTotal_quantity();
		left = d.get(j).getQuantity_left();
		n = left - total;
		d.get(j).setQuantity_left(n);
		d.get(j).setTotal_quantity(0);
			/*
			 * System.out.println(d.get(j)+"-------------"+d.get(j).getTotal_quantity()+
			 * "********"+d.get(j).getTotal_quantity()+"/////////");
			 * System.out.println(d.get(j)+"^^^^^^^^^^^^"+total+"$$$$$$$$$$$$$$$$"+left+
			 * "/////////");
		
			 */
		Stock s=new Stock();
		s.setId(d.get(j).getId());
		s.setItem(d.get(j).getItem());
		s.setPurchase_price(d.get(j).getPurchase_price());
		s.setQuantity_left(d.get(j).getQuantity_left());
		s.setSelling_price(d.get(j).getSelling_price());
		s.setTotal_quantity(d.get(j).getTotal_quantity());
		stockrepo.save(s);
		}
		System.out.println("++++++++++++++++++++++++++++++++++++");
		System.out.println(d);
		return "redirect:/bill";
	}
	
	
	
	
	@RequestMapping(path="/additem",method=RequestMethod.POST)
	public String addItem(Stock stock)
	{
		System.out.println(stock);
		stock.setTotal_quantity(0);
		stockrepo.save(stock);
		return "redirect:/add";
	}
	
	@RequestMapping(path="/login",method=RequestMethod.GET)
	public String StockController() {
		return "Home";
	
	}
	
	@RequestMapping(path="/add",method=RequestMethod.GET)
	public String StockControllers(ModelMap model) {
		model.addAttribute("stock",new Stock());
		return "Additem";

	}

	
	@RequestMapping(path="/bill",method=RequestMethod.GET)
	public String blist(ModelMap map)
	{
//		Stock s = new Stock();
		List<Stock> s = stockrepo.findAll();
		//System.out.println("this is s"+s);
		map.addAttribute("itemlist",s);
		System.out.println(s);
		return "BillPayment";
	}
	
	@RequestMapping(path="/quantity",method=RequestMethod.GET)
	public String quanlist(ModelMap qmap)
	{
		List<Stock> q = stockrepo.findAll();
		qmap.addAttribute("quantitylist",q);
		return "Quantity";
	}
	
	@RequestMapping(path="/edititem/{id}",method=RequestMethod.GET)
	public ModelAndView getItem(@PathVariable("id") int id) throws Exception
	{
		ModelAndView mv=new ModelAndView();
		mv.addObject("itemdetails",stockrepo.getOne(id));
		mv.setViewName("itemEdit");
		return mv;
	}
	
	@RequestMapping(path="/editquantity/{id}",method=RequestMethod.GET)
	public ModelAndView editquantiy(@PathVariable("id") int id) throws Exception
	{
		ModelAndView mv = new ModelAndView();
		mv.addObject("editquantity",stockrepo.getOne(id));
		mv.setViewName("quantityEdit");
		return mv;
	}
	
	@RequestMapping(path="/deleteitem/{id}",method=RequestMethod.GET)
	public String deleteItem(@PathVariable("id")int id) throws Exception
	{
		stockrepo.deleteById(id);		
		return "redirect:/quantity";
	}
	
	@RequestMapping(path="/updateitem",method=RequestMethod.POST)
	public String updateitems(Stock stock)
	{
		stockrepo.saveAndFlush(stock);
		return "redirect:/quantity";
	}
	
	@RequestMapping(path="/updatequantity",method=RequestMethod.POST)
	public String updatequanity(Stock stock)
	{
		stockrepo.saveAndFlush(stock);
		return "redirect:/bill";
	}
	
	
	@RequestMapping(path="/generatebill",method=RequestMethod.GET)
	public String buylist(ModelMap qmap)
	{
		List<Stock> q = stockrepo.findAll();
		qmap.addAttribute("boughtquantity",q);
		return "itemBought";
	}
	
	/*public ModelAndView getBill() throws Exception
	 {
		 ModelAndView mv=new ModelAndView();
		 mv.addObject("itemlist",stockrepo.findAll());
		 System.out.println("itemlist");
		 mv.setViewName("BillPayment");
		 return mv;
	 }
	*/
	

}
